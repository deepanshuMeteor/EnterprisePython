#! /usr/local/bin/python

first = 'Fred'
last  = 'Bloggs'
print(first, last)
